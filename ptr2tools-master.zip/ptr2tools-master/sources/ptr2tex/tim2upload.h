#ifndef TIM2UPLOAD_H
#define TIM2UPLOAD_H

bool tim2download(const void *tim2);
bool tim2upload(const void *tim2);

#endif // TIM2UPLOAD_H
